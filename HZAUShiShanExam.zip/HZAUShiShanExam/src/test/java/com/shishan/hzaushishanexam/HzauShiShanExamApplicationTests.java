package com.shishan.hzaushishanexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HzauShiShanExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
