package com.shishan.hzaushishanexam.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();

        // 关键配置：使用新API并显式暴露头
        config.addAllowedOriginPattern("*");  // 允许所有来源
        config.addAllowedHeader("*");         // 允许所有请求头
        config.addAllowedMethod("*");         // 允许所有HTTP方法
        config.setAllowCredentials(false);    // 关闭凭据（若需开启需指定具体域名）
        config.addExposedHeader("*");         // 暴露所有响应头（确保浏览器可访问CORS头）

        source.registerCorsConfiguration("/**", config); // 覆盖所有接口
        return new CorsFilter(source);
    }
}