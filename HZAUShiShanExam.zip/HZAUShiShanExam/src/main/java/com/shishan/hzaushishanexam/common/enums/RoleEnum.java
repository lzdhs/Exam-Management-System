package com.shishan.hzaushishanexam.common.enums;

public enum RoleEnum {
    // 管理员
    ADMIN,
    // 教师
    TEACHER,
    // 学生
    STUDENT
}
