package com.shishan.hzaushishanexam.mapper;

import java.util.List;

public interface StudentCourseMapper {
    List<String> getCourseNamesByStudentId(String studentId);
}