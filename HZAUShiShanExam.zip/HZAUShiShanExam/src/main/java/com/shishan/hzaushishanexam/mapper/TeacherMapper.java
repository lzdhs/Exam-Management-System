package com.shishan.hzaushishanexam.mapper;


import com.shishan.hzaushishanexam.entity.Teacher;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface TeacherMapper {

    int insert(Teacher teacher);

    void updateById(Teacher teacher);

    void deleteById(String id);

    @Select("select * from `teacher` where id = #{id}")
    Teacher selectById(String id);

    @Select("select * from `teacher` where name = #{name}")
    Teacher selectByName(String name);

    List<Teacher> selectAll(Teacher teacher);

}
