package com.shishan.hzaushishanexam.controller;


import com.github.pagehelper.PageInfo;
import com.shishan.hzaushishanexam.common.Result;
import com.shishan.hzaushishanexam.entity.TestPaper;
import com.shishan.hzaushishanexam.service.TestPaperService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

/**
 * 试卷信息前端请求接口
 */
@RestController
@RequestMapping("/testPaper")
public class TestPaperController {

    @Resource
    private TestPaperService testPaperService;

    /**
     * 新增试卷
     */
    @PostMapping("/add")
    public Result add(@RequestBody TestPaper testPaper) throws ParseException {
        testPaperService.add(testPaper);
        return Result.success();
    }

    /**
     * 修改试卷
     */
    @PutMapping("/update")
    public Result update(@RequestBody TestPaper testPaper) {
        testPaperService.updateById(testPaper);
        return Result.success();
    }

    /**
     * 单个删除试卷
     */
    @DeleteMapping("/delete/{id}")
    public Result delete(@PathVariable Integer id) {
        testPaperService.deleteById(id);
        return Result.success();
    }

    /**
     * 批量删除试卷
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        testPaperService.deleteBatch(ids);
        return Result.success();
    }

    /**
     * 单个查询试卷
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        TestPaper testPaper = testPaperService.selectById(id);
        return Result.success(testPaper);
    }

    /**
     * 检查试卷是否可作答
     */
    @GetMapping("/check/{id}")
    public Result check(@PathVariable Integer id) {
        testPaperService.checkTestPaper(id);
        return Result.success();
    }

    /**
     * 查询所有试卷
     */
    @GetMapping("/selectAll")
    public Result selectAll(TestPaper testPaper) {
        List<TestPaper> list = testPaperService.selectAll(testPaper);
        return Result.success(list);
    }

    /**
     * 分页查询试卷
     */
    @GetMapping("/selectPage")
    public Result selectPage(TestPaper testPaper,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) throws ParseException {
        PageInfo<TestPaper> pageInfo = testPaperService.selectPage(testPaper, pageNum, pageSize);
        return Result.success(pageInfo);
    }

    /**
     * 随机获取试卷（前端调用的关键接口）
     */
    @GetMapping("/selectRandom")
    public Result selectRandom() throws ParseException {
        List<TestPaper> list = testPaperService.selectRandom();
        return Result.success(list);
    }
}