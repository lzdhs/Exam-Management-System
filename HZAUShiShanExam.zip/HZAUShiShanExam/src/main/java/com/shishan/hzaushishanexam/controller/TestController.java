package com.shishan.hzaushishanexam.controller;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/test-cors")
    public ResponseEntity<String> testCors() {
        return ResponseEntity.ok()
                .header("Access-Control-Allow-Origin", "*") // 手动添加头
                .body("CORS Test");
    }
}