package com.shishan.hzaushishanexam.service;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONUtil;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.shishan.hzaushishanexam.common.enums.RoleEnum;
import com.shishan.hzaushishanexam.entity.*;
import com.shishan.hzaushishanexam.exception.CustomException;
import com.shishan.hzaushishanexam.mapper.*;
import com.shishan.hzaushishanexam.utils.TokenUtils;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 试卷信息业务层方法
 */
@Service
public class TestPaperService {

    @Resource
    private TestPaperMapper testPaperMapper;
    @Resource
    private QuestionMapper questionMapper;
    @Resource
    private CourseMapper courseMapper;
    @Resource
    private TeacherMapper teacherMapper;
    @Resource
    private ScoreMapper scoreMapper;

    @Resource
    private StudentCourseMapper studentCourseMapper;

    /**
     * 新增试卷（含数据校验）
     */
    public void add(TestPaper testPaper) throws ParseException {
        // 校验前台传过来的数据
        check(testPaper);

        Account currentUser = TokenUtils.getCurrentUser();
        testPaper.setTeacherId(currentUser.getId());

        // 手动选题逻辑
        if ("手动选题".equals(testPaper.getType())) {
            List<Integer> idList = testPaper.getIdList();
            testPaper.setQuestionIds(JSONUtil.toJsonStr(idList));
        }
        // 自动组卷逻辑
        else if ("自动组卷".equals(testPaper.getType())) {
            List<Integer> questionIds = new ArrayList<>();
            // 按题型随机获取题目
            randomQuestionIds(testPaper, testPaper.getChoiceNum(), questionIds, 1, "单选题");
            randomQuestionIds(testPaper, testPaper.getMultiChoiceNum(), questionIds, 2, "多选题");
            randomQuestionIds(testPaper, testPaper.getCheckNum(), questionIds, 3, "判断题");
            randomQuestionIds(testPaper, testPaper.getFillInNum(), questionIds, 4, "填空题");
            randomQuestionIds(testPaper, testPaper.getAnswerNum(), questionIds, 5, "简答题");
            testPaper.setQuestionIds(JSONUtil.toJsonStr(questionIds));
        }

        testPaperMapper.insert(testPaper);
    }

    /**
     * 随机获取题目（修正拼写错误：couserId → courseId）
     */
    private void randomQuestionIds(TestPaper testPaper, Integer questionCount, List<Integer> resultList, Integer questionTypeId, String questionTypeName) {
        // 修正为 courseId（原拼写为 couserId）
        List<Question> questionList = questionMapper.selectByCouserIdAndTypeId(testPaper.getCourseId(), questionTypeId);

        if (questionList.size() < questionCount) {
            throw new CustomException("-1", "题库中" + questionTypeName + "数量不足（需" + questionCount + "道，现有" + questionList.size() + "道）");
        }

        Collections.shuffle(questionList); // 打乱题目顺序
        List<Integer> selectedIds = questionList.subList(0, questionCount).stream()
                .map(Question::getId)
                .collect(Collectors.toList());
        resultList.addAll(selectedIds);
    }

    /**
     * 数据校验
     */
    private void check(TestPaper testPaper) throws ParseException {
        if (ObjectUtil.isEmpty(testPaper.getName())
                || ObjectUtil.isEmpty(testPaper.getCourseId())
                || ObjectUtil.isEmpty(testPaper.getStart())
                || ObjectUtil.isEmpty(testPaper.getEnd())
                || ObjectUtil.isEmpty(testPaper.getTime())
                || ObjectUtil.isEmpty(testPaper.getType())) {
            throw new CustomException("-1", "请填写完整试卷信息");
        }

        // 校验时间顺序
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = sdf.parse(testPaper.getStart());
        Date endDate = sdf.parse(testPaper.getEnd());
        if (startDate.getTime() >= endDate.getTime()) {
            throw new CustomException("-1", "开始时间必须早于结束时间");
        }

        // 手动选题校验
        if ("手动选题".equals(testPaper.getType()) && CollectionUtil.isEmpty(testPaper.getIdList())) {
            throw new CustomException("-1", "手动选题需选择具体题目");
        }

        // 自动组卷校验
        if ("自动组卷".equals(testPaper.getType())) {
            if (testPaper.getChoiceNum() < 0 || testPaper.getMultiChoiceNum() < 0 ||
                    testPaper.getFillInNum() < 0 || testPaper.getCheckNum() < 0 ||
                    testPaper.getAnswerNum() < 0) {
                throw new CustomException("-1", "题型数量不能为负数");
            }
        }
    }

    /**
     * 修改试卷
     */
    public void updateById(TestPaper testPaper) {
        testPaperMapper.updateById(testPaper);
    }

    /**
     * 单个删除试卷
     */
    public void deleteById(Integer id) {
        testPaperMapper.deleteById(id);
    }

    /**
     * 批量删除试卷
     */
    public void deleteBatch(List<Integer> ids) {
        ids.forEach(this::deleteById);
    }

    /**
     * 单个查询试卷（含关联数据填充）
     */
    public TestPaper selectById(Integer id) {
        TestPaper testPaper = testPaperMapper.selectById(id);

        // 填充课程名称和教师信息
        Course course = courseMapper.selectById(testPaper.getCourseId());
        if (ObjectUtil.isNotEmpty(course)) {
            testPaper.setCourseName(course.getName());
            testPaper.setCourseImg(course.getImg());
        }
        Teacher teacher = teacherMapper.selectById(testPaper.getTeacherId());
        if (ObjectUtil.isNotEmpty(teacher)) {
            testPaper.setTeacherName(teacher.getName());
            testPaper.setTeacherAvatar(teacher.getAvatar());
        }

        // 解析题目ID并查询题目列表
        List<Integer> questionIds = JSONUtil.toList(testPaper.getQuestionIds(), Integer.class);
        List<Question> questions = questionIds.stream()
                .map(questionMapper::selectById)
                .collect(Collectors.toList());
        testPaper.setQuestions(questions);

        // 计算总时长（分钟转秒）
        testPaper.setMaxTime(testPaper.getTime() * 60);
        return testPaper;
    }

    /**
     * 查询所有试卷（含状态初始化）
     */
    public List<TestPaper> selectAll(TestPaper testPaper) {
        List<TestPaper> list = testPaperMapper.selectAll(testPaper);
        try {
            initStatus(list);
        } catch (ParseException e) {
            throw new CustomException("-1", "试卷状态初始化失败");
        }
        return list;
    }

    /**
     * 分页查询试卷（含权限过滤）
     */
    public PageInfo<TestPaper> selectPage(TestPaper testPaper, Integer pageNum, Integer pageSize) throws ParseException {
        Account currentUser = TokenUtils.getCurrentUser();
        List<TestPaper> list=new ArrayList<>();

        // 教师角色仅能查询自己创建的试卷
        if (RoleEnum.TEACHER.name().equals(currentUser.getRole())) {
            testPaper.setTeacherId(currentUser.getId());
            list = testPaperMapper.selectAll(testPaper);
            initStatus(list);
        }
        else{
            if(RoleEnum.STUDENT.name().equals(currentUser.getRole())){
                System.out.println();
                //System.out.println("juiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiuiui");
                System.out.println();
                List<String> cous=studentCourseMapper.getCourseNamesByStudentId(currentUser.getId());
                List<TestPaper> tempPapers = new ArrayList<>(); // 临时存储查询结果
                for (String course1 : cous) {
                    TestPaper testPaper1 = new TestPaper();
                    System.out.println();
                    System.out.println("目前课程为:"+course1);
                    System.out.println();
                    System.out.println();
                    testPaper1.setCourseName(course1);
                    tempPapers.addAll(testPaperMapper.selectAll(testPaper1));
                }
                list.addAll(tempPapers);
            }else{
                list = testPaperMapper.selectAll(testPaper);
                initStatus(list);
            }
        }
        //原装
        /*
        PageHelper.startPage(pageNum, pageSize);
        List<TestPaper> list = testPaperMapper.selectAll(testPaper);
        initStatus(list);
         */
        initStatus(list);
        //PageHelper.startPage(pageNum, pageSize);
        return PageInfo.of(list);
    }

    /**
     * 初始化试卷状态（进行中/未开始/已结束）
     */
    private void initStatus(List<TestPaper> list) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = new Date();
        for (TestPaper paper : list) {
            Date startDate = sdf.parse(paper.getStart() + " 00:00:00");
            Date endDate = sdf.parse(paper.getEnd() + " 23:59:59");

            if (now.before(startDate)) {
                paper.setStatus("未开始");
            } else if (now.after(endDate)) {
                paper.setStatus("已结束");
            } else {
                paper.setStatus("进行中");
            }
        }
    }

    /**
     * 检查用户是否已作答过该试卷
     */
    public void checkTestPaper(Integer id) {
        Account currentUser = TokenUtils.getCurrentUser();
        Score queryScore = new Score();
        queryScore.setPaperId(id);
        queryScore.setStudentId(currentUser.getId());

        List<Score> scores = scoreMapper.selectAll(queryScore);
        if (CollectionUtil.isNotEmpty(scores)) {
            throw new CustomException("-1", "您已提交过该试卷，无法重复作答");
        }
    }

    /**
     * 随机获取试卷列表（用于前端首页推荐）
     */
    public List<TestPaper> selectRandom() throws ParseException {
        //List<TestPaper> allPapers = testPaperMapper.selectAll(new TestPaper());
        List<TestPaper> allPapers = new ArrayList<>();
        List<String> cous=studentCourseMapper.getCourseNamesByStudentId(TokenUtils.getCurrentUser().getId());
        List<TestPaper> tempPapers = new ArrayList<>(); // 临时存储查询结果
        for (String course1 : cous) {
            TestPaper testPaper = new TestPaper();
            testPaper.setCourseName(course1);
            tempPapers.addAll(testPaperMapper.selectAll(testPaper));
        }
        allPapers.addAll(tempPapers);

        Collections.shuffle(allPapers); // 打乱试卷顺序

        // 初始化状态
        initStatus(allPapers);

        // 最多返回4条数据
        return allPapers.size() > 4 ? allPapers.subList(0, 4) : allPapers;
    }
}