package com.shishan.hzaushishanexam.mapper;

import com.shishan.hzaushishanexam.entity.ExamPlan;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ExamPlanMapper {

    int insert(ExamPlan examPlan);

    void updateById(ExamPlan examPlan);

    void deleteById(Integer id);

    @Select("select * from `exam_plan` where id = #{id}")
    ExamPlan selectById(Integer id);

    List<ExamPlan> selectAll(ExamPlan examPlan);

}
