package com.shishan.hzaushishanexam;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan({"com.shishan.hzaushishanexam.mapper"})
@SpringBootApplication
public class HzauShiShanExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(HzauShiShanExamApplication.class, args);
	}

}
