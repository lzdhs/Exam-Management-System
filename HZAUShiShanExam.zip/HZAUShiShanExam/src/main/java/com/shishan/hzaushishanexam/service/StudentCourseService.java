package com.shishan.hzaushishanexam.service;

import com.shishan.hzaushishanexam.mapper.StudentCourseMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentCourseService {
    @Resource
    private StudentCourseMapper studentCourseMapper;

    // 提供构造方法进行依赖注入
    public StudentCourseService(StudentCourseMapper studentCourseMapper) {
        this.studentCourseMapper = studentCourseMapper;
    }

    List<String> getCourseIds(String studentId){
        return studentCourseMapper.getCourseNamesByStudentId(studentId);
    }
}