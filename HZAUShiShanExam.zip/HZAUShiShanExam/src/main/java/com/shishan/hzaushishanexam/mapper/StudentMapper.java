package com.shishan.hzaushishanexam.mapper;


import com.shishan.hzaushishanexam.entity.Student;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface StudentMapper {

    int insert(Student student);

    void updateById(Student student);

    void deleteById(String id);

    @Select("select * from `student` where id = #{id}")
    Student selectById(String id);

    @Select("select * from `student` where name = #{name}")
    Student selectByName(String name);

    List<Student> selectAll(Student student);

}
