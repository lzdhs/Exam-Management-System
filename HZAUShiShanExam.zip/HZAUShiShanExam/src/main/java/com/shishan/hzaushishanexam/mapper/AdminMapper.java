package com.shishan.hzaushishanexam.mapper;


import com.shishan.hzaushishanexam.entity.Admin;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface AdminMapper {

    int insert(Admin admin);

    void updateById(Admin admin);

    void deleteById(String id);

    @Select("select * from `admin` where id = #{id}")
    Admin selectById(String id);

    @Select("select * from `admin` where name = #{name}")
    Admin selectByName(String name);

    List<Admin> selectAll(Admin admin);

}
